<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\EditController;
use App\Models\Editor;
use App\Policy\EditorPolicy;

class EditorController extends Controller
{
    
    public function view(Request $request){
        if ($request->user()->cannot('viewAny', Editor::class)) {
            abort(403);
        }

        return view('editor.editor');
    
}


}
