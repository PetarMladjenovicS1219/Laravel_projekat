<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;




namespace App\Http\Controllers;
use App\Models\Comment;
use App\Http\Controllers\Controller;
use App\Policy\CommentPolicy;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Pagination\Paginator;

use Session;


class CommentController extends Controller
{
    
    public function add(){
        return view('comment.add');
    }


    
    public function insert(Request $request){

        if ($request->user()->cannot('create', Comment::class)) {
            abort(403);
        }

        $this->validate($request, [
            'Ime' => 'required',
            'Prezime' => 'required',
            'Adresa' => 'required',
        ]);
        
        $postsData = $request->all();
        
  
        Comment::create($postsData);
        
       
        Session::flash('success_msg', 'Komentar je poslat u bazu uspesno!');
    
        return redirect()->route('products.products');
    
    }
}
