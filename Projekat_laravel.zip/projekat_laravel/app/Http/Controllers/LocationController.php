<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Location;

use Session;

use Illuminate\Pagination\Paginator;

class LocationController extends Controller
{
    
    public function location(Request $request){

        if($request->has('q')){
            $q = $request->get('q');
            $locations = Location::where('Grad', 'LIKE', "%{$q}%" )->paginate(5);
        }else{
            $locations = Location::paginate(5); 
        }
        
        
        
        
        return view('location.location', ['locations' => $locations]);
    }
   public function details($id){
    
        $locations = Location::find($id);
        
     
        return view('location.details', ['locations' => $locations]);
    }
 
}
