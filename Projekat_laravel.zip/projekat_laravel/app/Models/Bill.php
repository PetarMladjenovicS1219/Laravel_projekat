<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Policies\BillPolicy;
class Bill extends Model
{
    protected $fillable = ['sifra_racuna','iznos','nacin_placanja'];

    const CREATED_AT = 'created';
    const UPDATED_AT =  'created';
}
