<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\AdminController;
use App\Models\Admin;
use App\Policy\AdminPolicy;



class AdminController extends Controller
{
    public function view(Request $request){
        if ($request->user()->cannot('viewAny', Admin::class)) {
            abort(403);
        }
    return view('admin.admin');
}


}