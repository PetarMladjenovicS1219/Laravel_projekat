<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
        Product::class => ProductPolicy::class,
        Storage::class => StoragePolicy::class,
        Bill::class => BillPolicy::class,
        Order::class => OrderPolicy::class,
        Comment::class => CommentPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Gate::define('update-product',[ ProductPolicy::class,'update']);
        Gate::define('create-product',[ ProductPolicy::class,'create']);
        Gate::define('delete-product',[ProductPolicy::class,'delete']);
        Gate::define('create-order',[OrderPolicy::class,'create']);
        Gate::define('create-storage',[StoragePolicy::class,'create']);
        Gate::define('update-storage',[StoragePolicy::class,'update']);
        Gate::define('create-bill',[BillPolicy::class,'create']);
        Gate::define('view-bill',[BillPolicy::class,'view']);
        Gate::define('create-comment',[CommentPolicy::class,'create']);
        Gate::define('view-storage',[StoragePolicy::class,'view']);
        Gate::define('create-comment',[CommentPolicy::class,'create']);
        Gate::define('view-admin',[AdminPolicy::class,'view']);
        Gate::define('view-editor',[EditorPolicy::class,'view']);
    }
}
