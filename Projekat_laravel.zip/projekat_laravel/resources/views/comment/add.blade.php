@extends('lay.app')
@extends('layouts.app')

@section('cont')
<div class="row">
    <div class="col-lg-12">
        @if($errors->any())
            <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach()
            </div>
        @endif
        <div class="panel panel-default">
            <div class="panel-heading">
                 <a href="{{ route('products.products') }}" class="label label-primary pull-right">Nazad</a>
            </div>
            <div class="panel-body">
                <form action="{{ route('comment.insert') }}" method="POST" class="form-horizontal">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Ime</label>
                        <div class="col-sm-10">
                            <input type="text" name="Ime" id="Ime" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Prezime</label>
                        <div class="col-sm-10">
                        <input type="text" name="Prezime" id="Prezime" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Adresa</label>
                        <div class="col-sm-10">
                        <input type="text" name="Adresa" id="Adresa" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Komentar</label>
                        <div class="col-sm-10">
                        <textarea name="Komentar" id="Komentar" class="form-control"></textarea>
                    </div><br>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Datum:</label>
                        <div class="col-sm-10">
                        <input type="date" name="Datum" id="Datum" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-default" value="Add Post" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection