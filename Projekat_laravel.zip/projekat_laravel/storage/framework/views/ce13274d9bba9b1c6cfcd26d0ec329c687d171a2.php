<?php echo $__env->yieldContent('adm'); ?>

   
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Godina', 'Prodaja', 'Troskovi', 'Profit'],
          ['2018', 1000, 400, 200],
          ['2019', 1170, 460, 250],
          ['2020', 660, 1120, 300],
          ['2021', 1030, 540, 350]
        ]);

        var options = {
          chart: {
            title: 'Performanse Apoteke',
            subtitle: 'Prodaja, Troskovi, i Profit: 2018-2021',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/grap/adm.blade.php ENDPATH**/ ?>