<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Storage extends Model
{
    protected $fillable = ['Naziv_proizvoda', 'Kolicina_proizvoda','Rok_trajanja','Datum_nabavke'];
    
    const CREATED_AT = 'Rok_trajanja';
    
    const UPDATED_AT = 'Datum_nabavke';
    
}
