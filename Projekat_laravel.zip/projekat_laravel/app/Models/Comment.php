<?php

namespace App\Models;
use App\Policies\CommentPolicy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $fillable = ['Ime', 'Prezime','Adresa','Komentar','Datum'];

    const CREATED_AT = 'Datum';
    const UPDATED_AT = 'Datum';
    
}
