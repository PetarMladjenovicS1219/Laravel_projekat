<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Storage;

use Session;
use Illuminate\Pagination\Paginator;
class StorageController extends Controller
{
    
    public function storage(Request $request){

        if ($request->user()->cannot('viewAny', Bill::class)) {
            abort(403);
        }

        if($request->has('q')){
            $q = $request->get('q');
            $storages = Storage::where('Naziv_proizvoda', 'LIKE', "%{$q}%" )->paginate(5);
        }else{
            $storages = Storage::paginate(5);
        }

        
        return view('storage.storage',['storages'=>$storages]);
    }
    
    public function details($id){
        $storages = Storage::find($id);
        return view('storage.details',['storages'=>$storages]);
    }


    public function add(){
        return view('storage.add');
    }


    
    public function insert(Request $request){

        if ($request->user()->cannot('create', Product::class)) {
            abort(403);
        }

        $this->validate($request, [
            'Kolicina_proizvoda' => 'required'
        ]);
        
        $postsData = $request->all();
        
  
        Storage::create($postsData);
        
       
        Session::flash('success_msg', 'Proizvod je dodat u bazu magacin uspesno!');
    
        return redirect()->route('storage.storage');
    
    }
    
    
    public function edit($id){
       
        $storages = Storage::find($id);
        
        
        return view('storage.edit', ['storages' => $storages]);
    }
    
    public function update($id, Request $request){
        $p = Storage::find($id);

    if ($request->user()->cannot('update', $p)) {
       abort(403);
    }


        //validate post data
        $this->validate($request, [
            'Kolicina_proizvoda' => 'required'
        
        ]);
        
        //get post data
        $postData = $request->all();
        
        //update post data
       $p=Storage::find($id);
        
       $p->update($postData);
        //store status message
        Session::flash('success_msg', 'Proizvod je uspesno azuriran u bazi magacin!');
    
        return redirect()->route('storage.storage');
    }
    
    
    
    


}
