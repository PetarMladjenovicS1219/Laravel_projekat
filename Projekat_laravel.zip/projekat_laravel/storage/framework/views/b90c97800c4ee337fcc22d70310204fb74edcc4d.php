


<?php $__env->startSection('cont'); ?>
<div class="row">
    <div class="col-lg-12">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                Add a New Post <a href="<?php echo e(route('orders.orders')); ?>" class="label label-primary pull-right">Nazad</a>
            </div>
            <div class="panel-body">
                <form action="<?php echo e(route('bills.insert')); ?>" method="POST" class="form-horizontal">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="control-label col-sm-2" >Sifra racuna</label>
                        <div class="col-sm-10">
                            <input type="text" name="sifra_racuna" id="sifra_racuna" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Iznos</label>
                        <div class="col-sm-10">
                            <input type="text" name="iznos" id="iznos" class="form-control">
                        </div>
                    </div>
                    
                   
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Datum</label>
                        <div class="col-sm-10">
                        <input type="date" name="datum_placanja" id="datum_placanja" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Nacin placanja</label>
                        <div class="col-sm-10">
                            <input type="text" name="nacin_placanja" id="nacin_placanja" class="form-control">
                        </div>
                    </div>
                   
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-default" value="Add Post" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('lay.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/bills/add.blade.php ENDPATH**/ ?>