@extends('layout.app')
@extends('layouts.app')




@section('content')
    <div class="container">
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif

        @endsection


        @section('header')

<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
      
      </nav>
      <a href="{{route('editori.editor')}}" class="appointment-btn scrollto">Editor</a>

      <a href="{{route('admin.admin')}}" class="appointment-btn scrollto">Admin</a>

      <a href="{{route('register')}}" class="appointment-btn scrollto">Register</a>

      <a href="{{route('login')}}" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


@endsection


        @section('hero')

<section id="hero" class="d-flex align-items-center">
    <div class="container">
    
      <h1>Dobrodosli na home stranicu</h1>
      <h2>Najbolja apoteka samo uz Vas</h2><br><br>
      <strong><a href="/projekat_laravel/public"class="appointment-btn scrollto">Kliknite za pristup sajtu </a></strong>
     
     
    </div>
  </section>


@endsection