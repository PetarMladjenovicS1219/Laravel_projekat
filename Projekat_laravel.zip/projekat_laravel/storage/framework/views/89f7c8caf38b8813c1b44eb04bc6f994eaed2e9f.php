




			<?php $__env->startSection('cont'); ?>
			<div class="row">
				<div class="col-lg-12 margin-tb">
					<div class="pull-left">
						<h2>Apoteka Mladjenovic</h2>
					</div>
					<div class="pull-right">
						<a href="<?php echo e(route('storage.storage')); ?>" class="label label-primary pull-right">Nazad</a>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Naziv Proizvoda:</strong>
						<?php echo e($storages->Naziv_proizvoda); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Kolicina proizvoda:</strong>
						<?php echo e($storages->Kolicina_proizvoda); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Rok trajanja:</strong>
						<?php echo e($storages->Rok_trajanja); ?>

					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Datum nabavke:</strong>
						<?php echo e($storages->Datum_nabavke); ?>

					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/storage/details.blade.php ENDPATH**/ ?>