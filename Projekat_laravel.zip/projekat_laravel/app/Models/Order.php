<?php

namespace App\Models;
use App\Http\Controllers\OrderController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['Ime_Prezime', 'Naziv_proizvoda'];
    const CREATED_AT = 'datum_narucivanja';
    const UPDATED_AT =  'datum_narucivanja';
    
}
