@extends('lay.app')
@extends('layouts.app')




			@section('cont')
			<div class="row">
				<div class="col-lg-12 margin-tb">
					<div class="pull-left">
						<h2>Apoteka Mladjenovic</h2>
					</div>
					<div class="pull-right">
						<a href="{{ route('location.location') }}" class="label label-primary pull-right">Nazad</a>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Naziv Apoteke:</strong>
						{{ $locations->Naziv_Apoteke }}
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Grad:</strong>
						{{ $locations->Grad }}
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Adresa:</strong>
						{{$locations->Adresa }}
					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Postanski broj:</strong>
						{{$locations->Postanski_broj }}
					</div>
				</div>
			</div>
			@endsection

