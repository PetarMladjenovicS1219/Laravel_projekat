





<?php $__env->startSection('header'); ?>
<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="/projekat_laravel/public">Pocetna</a></li>
		  <li class="active"><a href="<?php echo e(route('products.products')); ?>">Proizvodi</a></li>
		  <li><a href="<?php echo e(route('orders.orders')); ?>">Narudzbenice</a></li>
          <li><a href="<?php echo e(route('location.location')); ?>">Lokacije</a></li>
          <li><a href="<?php echo e(route('storage.storage')); ?>">Magacin</a></li>
          <li><a href="<?php echo e(route('bills.bills')); ?>">Racuni</a></li>
          <li class="drop-down"><a href="">Apoteka</a>
            <ul>
              <li><a href="/projekat_laravel/public/onama">O nama</a></li>
              
              <li><a href="/projekat_laravel/public/saveti">Saveti</a></li>
              
            </ul>
          </li>
         
        </ul>
      </nav>
      <a href="<?php echo e(route('register')); ?>" class="appointment-btn scrollto">Register</a>

      <a href="<?php echo e(route('login')); ?>" class="appointment-btn scrollto">Login</a>

    </div>
  </header>

<?php $__env->stopSection(); ?>



			<?php $__env->startSection('cont'); ?>
			<div class="row">
				<div class="col-lg-12">
					<?php if(Session::has('success_msg')): ?>
					<div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
					<?php endif; ?>
				<!-- Posts list -->
				<?php if(!empty($products)): ?>
					<div class="row">
						<div class="col-lg-12 margin-tb">
							<div class="pull-left">
								<h2>Katalog proizvoda</h2>
							</div>
							<div class="pull-right">
                                <?php if(auth()->guard()->check()): ?>
								<a class="btn btn-success" href="<?php echo e(route('products.add')); ?>">Dodaj novi proizvod</a>
								<?php endif; ?>
								<a class="btn btn-success" href="<?php echo e(route('orders.add')); ?>">Narucite proizvod</a>
							</div>
						</div>
					</div>
					<?php echo $products->appends(Request::all())->links(); ?>

					<form action="<?php echo e(route('products.products')); ?>" method="get" role="search">
	    <?php echo e(csrf_field()); ?>

            <div class="input-group">
					<input type="text" class="form-control" name="q" placeholder="Search"> 
                    <span class="input-group-btn">
                    <button type="submit" class="btn btn-default">
                        <span class="glyphicon glyphicon-search"></span>
                    </button>
                </span>
            </div>
        </form>
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12">
							<table class="table table-striped task-table">
								<!-- Table Headings -->
								<thead>
									<th width="25%">Naziv proizvoda</th>
									<th width="15%">Sifra proizvoda</th>
									<th width="15%">Opis proizvoda</th>

									<th width="20%">Cena proizvoda</th>
									<th width="20%">Datum stavljanja u promet</th>

								</thead>
				
								<!-- Table Body -->
								<tbody>
								<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td class="table-text">
											<div><?php echo e($product->naziv_proizvoda); ?></div>
										</td>
										<td class="table-text">
											<div><?php echo e($product->sifra_proizvoda); ?></div>
										</td>
									
											<td class="table-text">
											<div><?php echo e($product->opis_proizvoda); ?></div>
										</td>
										<td class="table-text">
											<div><?php echo e($product->cena_proizvoda); ?></div>
										</td>
                    <td class="table-text">
											<div><?php echo e($product->datum_stavljanja_u_promet); ?></div>
										</td>
										<td>
										
											<a href="<?php echo e(route('products.details', $product->id)); ?>" class="label label-success">Detaljnije</a>
											<?php if(auth()->guard()->check()): ?>
											<a href="<?php echo e(route('products.edit', $product->id)); ?>" class="label label-warning">Izmeni</a>
											<a href="<?php echo e(route('products.delete', $product->id)); ?>" class="label label-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
						<?php if(auth()->guard()->check()): ?>
			<a class="btn btn-success" href="<?php echo e(route('comment.add')); ?>">Dodaj komentar</a>
		
			<?php endif; ?>
					</div>
				<?php endif; ?>
				</div>
			       
			</div>
			<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('lay.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/products/products.blade.php ENDPATH**/ ?>