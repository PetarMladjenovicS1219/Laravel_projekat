<?php


namespace App\Http\Controllers;
use App\Models\Product;
use App\Http\Controllers\Controller;
use App\Policy\ProductPolicy;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Pagination\Paginator;

use Session;



class ProductController extends Controller
{
    
public function products(Request $request){

if($request->has('q')){
    $q = $request->get('q');
    $products = Product::where('naziv_proizvoda', 'LIKE', "%{$q}%" )->orWhere('opis_proizvoda', 'LIKE', "%{$q}%")->paginate(5);
}else{
    $products = Product::paginate(5);  
}

    return view('products.products',['products'=>$products]);
}

public function details($id){
    $products = Product::find($id);
    return view('products.details',['products'=>$products]);
}
public function add(Request $request){
   
    return view('products.add');
}

public function insert(Request $request){
    
    if ($request->user()->cannot('create', Product::class)) {
        abort(403);
    }


    $this->validate($request, [
        'naziv_proizvoda' => 'required',
        'sifra_proizvoda' => 'required',
        'opis_proizvoda' => 'required',
        'cena_proizvoda' => 'required',
        'datum_stavljanja_u_promet'=> 'required'
    ]);

    
  
    
    //get post data
    $postData = $request->all();

  
    //insert post data
    Product::create($postData);
    
    //store status message
    Session::flash('success_msg', 'Proizvod je dodat u bazu uspesno!');

    return redirect()->route('products.products');

}


public function edit($id){
    //get post data by id
    $products = Product::find($id);
    
    //load form view
    return view('products.edit', ['products' => $products]);
}

public function update($id, Request $request){
    
    $p = Product::find($id);

    if ($request->user()->cannot('update', $p)) {
       abort(403);
    }
    
    //validate post data
    $this->validate($request, [
        'naziv_proizvoda' => 'required'
    
    ]);
    
    //get post data
    $postData = $request->all();
    
    //update post data
    $p = Product::find($id);
    $p->update($postData);
    
    //store status message
    Session::flash('success_msg', 'Proizvod je izmenjen uspesno!');

    return redirect()->route('products.products');
}



public function delete($id, Request $request){
    $p = Product::find($id);
    if($request->user()->cannot('delete', $p)){
        abort(403);
    }
    Product::find($id)->delete();


    Session::flash('success_msg', 'Uspesno obrisan proizvod!');

    return redirect()->route('products.products');

}

}
