





<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php $__env->stopSection(); ?>


        <?php $__env->startSection('header'); ?>

<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
      
      </nav>
      <a href="<?php echo e(route('editori.editor')); ?>" class="appointment-btn scrollto">Editor</a>

      <a href="<?php echo e(route('admin.admin')); ?>" class="appointment-btn scrollto">Admin</a>

      <a href="<?php echo e(route('register')); ?>" class="appointment-btn scrollto">Register</a>

      <a href="<?php echo e(route('login')); ?>" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


<?php $__env->stopSection(); ?>


        <?php $__env->startSection('hero'); ?>

<section id="hero" class="d-flex align-items-center">
    <div class="container">
    
      <h1>Dobrodosli na home stranicu</h1>
      <h2>Najbolja apoteka samo uz Vas</h2><br><br>
      <strong><a href="/projekat_laravel/public"class="appointment-btn scrollto">Kliknite za pristup sajtu </a></strong>
     
     
    </div>
  </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/home.blade.php ENDPATH**/ ?>