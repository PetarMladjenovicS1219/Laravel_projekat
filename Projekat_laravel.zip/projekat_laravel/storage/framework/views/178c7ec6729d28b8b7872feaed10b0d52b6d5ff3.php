<?php $__env->startSection('bar'); ?>

<div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:contact@example.com">pmladjenovic1219s@raf.rs</a>
        <i class="icofont-phone"></i> +381 60 72 60 180
        <i class="icofont-google-map"></i> Zeleznicka 85, UE
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="skype"><i class="icofont-skype"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>

<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="/projekat_laravel/public">Pocetna</a></li>
          <li><a href="<?php echo e(route('products.products')); ?>">Proizvodi</a></li>
          <li><a href="<?php echo e(route('orders.orders')); ?>">Narudzbenice</a></li>
          <li><a href="<?php echo e(route('location.location')); ?>">Lokacije</a></li>
          <li><a href="<?php echo e(route('storage.storage')); ?>">Magacin</a></li>
          <li><a href="<?php echo e(route('bills.bills')); ?>">Racuni</a></li>
          <li class="drop-down"><a href="">Apoteka</a>
            <ul>
            <li><a href="/projekat_laravel/public/onama">O nama</a></li>
              
              <li><a href="/projekat_laravel/public/saveti">Saveti</a></li>
              
            </ul>
          
      </nav>
      <a href="<?php echo e(route('register')); ?>" class="appointment-btn scrollto">Register</a>

      <a href="<?php echo e(route('login')); ?>" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('hero'); ?>

<section id="hero" class="d-flex align-items-center">
    <div class="container">
    
      <h1>Dobrodosli na pocetnu stranicu</h1>
      <h2>Najbolja apoteka samo uz Vas</h2>
     
     
    </div>
  </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('section'); ?>


<main id="main">

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="row">
          <div class="col-lg-4 d-flex align-items-stretch">
            <div class="content">
              <h3>Zasto bas mi</h3>
              <p>
              Mladjenovic apoteke odlikuje nov i moderan pristup u sprovođenju farmaceutske usluge u oblasti medicinske zaštite i prevencije. Prillagođena zahtevima savremenog potrošača, Mladjenovic apoteka pruža mogućnost samostalnog istraživanja proizvoda uz konsultacije sa stručnim farmaceutima i u skladu sa principima dobre farmaceutske prakse.
              </p>
             
            </div>
          </div>
          <div class="col-lg-8 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-receipt"></i>
                    <h4>Uvek uz vas</h4>
                    <p>Kontaktirajte nas 00-24</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-cube-alt"></i>
                    <h4>Clanci i saveti</h4>
                    <p>Nasa stranica o clancima i savetima. Posetite je!</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-images"></i>
                    <h4>Galerija</h4>
                    <p>Galerija slika nasih lekara i nasih apoteka</p>
                  </div>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>Apoteka Mladjenovic</h3>
        <p>
         Zeleznicka 85 <br>
          Uzice, UE 31000<br>
          Srbija <br><br>
          <strong>Phone:</strong> 060 123 4567<br>
          <strong>Email:</strong>pmladjenovc1219s@raf.rs<br>
        </p>
      </div>



     

      <div class="col-lg-4 col-md-6 footer-newsletter">
        <h4>Pridruzite se nasem timu</h4>
        <p>Posaljite Vas CV i pokusajte da postanete deo najbolje apoteke u Srbiji</p>
        <form action="" method="post">
          <input type="email" name="email"><input type="submit" value="Posalji">
        </form>
      </div>

    </div>
  </div>
</div>

<div class="container d-md-flex py-4">

  <div class="mr-md-auto text-center text-md-left">
    <div class="copyright">
      &copy; Copyright <strong><span>Apoteka Mladjenovic</span></strong>
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </div>
  <div class="social-links text-center text-md-right pt-3 pt-md-0">
    <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
    <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
    <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
    <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
    <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
  </div>
</div>
</footer><!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/venobox/venobox.min.js"></script>
<script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="assets/vendor/counterup/counterup.min.js"></script>
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>