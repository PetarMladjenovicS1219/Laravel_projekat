@extends('lay.app')
@extends('layouts.app')
@extends('layout.app')


@section('header')

<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
        <li><a href="/projekat_laravel/public">Pocetna</a></li>
          <li><a href="{{ route('products.products') }}">Proizvodi</a></li>
		  <li><a href="{{ route('orders.orders')}}">Narudzbenice</a></li>
          <li><a href="{{ route('location.location') }}">Lokacije</a></li>
		  <li class="active"><a href="{{route('storage.storage')}}">Magacin</a></li>
          <li><a href="{{route('bills.bills')}}">Racuni</a></li>
          <li class="drop-down"><a href="">Apoteka</a>
            <ul>
              <li><a href="/projekat_laravel/public/onama">O nama</a></li>
              
              <li><a href="/projekat_laravel/public/saveti">Saveti</a></li>
              
            </ul>
          </li>
         
        </ul>
      </nav>
      <a href="{{route('register')}}" class="appointment-btn scrollto">Register</a>

      <a href="{{route('login')}}" class="appointment-btn scrollto">Login</a>

    </div>
  </header>



@endsection



			@section('cont')
			<div class="row">
				<div class="col-lg-12">
					@if(Session::has('success_msg'))
					<div class="alert alert-success">{{ Session::get('success_msg') }}</div>
					@endif
				<!-- Posts list -->
				@if(!empty($storages))
					<div class="row">
						<div class="col-lg-12 margin-tb">
							<div class="pull-left">
								<h2>Magacin proizvoda</h2>
							</div>
							<div class="pull-right">
								<a class="btn btn-success" href="{{ route('storage.add') }}">Dodaj novi proizvod u magacin</a>
							</div>
						</div>
					</div>
					{!! $storages->appends(Request::all())->links() !!}
					<form action="{{ route('storage.storage') }}" method="get" role="search">
	    {{ csrf_field() }}
            <div class="input-group">
					<input type="text" class="form-control" name="q" placeholder="Search"> 
                    <span class="input-group-btn">
                    <button type="submit" class="btn btn-default">
                        <span class="glyphicon glyphicon-search"></span>
                    </button>
                </span>
            </div>
        </form>
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12">
							<table class="table table-striped task-table">
								<!-- Table Headings -->
								<thead>
									<th width="25%">Naziv proizvoda</th>
									<th width="20%">Kolicina proizvoda</th>
									<th width="35%">Rok trajanja</th>
									<th width="20%">Datum nabavke</th>

								</thead>
				
								<!-- Table Body -->
								<tbody>
								@foreach($storages as $storage)
									<tr>
										<td class="table-text">
											<div>{{$storage->Naziv_proizvoda}}</div>
										</td>
										<td class="table-text">
											<div>{{$storage->Kolicina_proizvoda}}</div>
										</td>
											<td class="table-text">
											<div>{{$storage->Rok_trajanja}}</div>
										</td>
                    <td class="table-text">
											<div>{{$storage->Datum_nabavke}}</div>
										</td>
										<td>
											<a href="{{ route('storage.details', $storage->id) }}" class="label label-success">Detaljnije</a>
											<a href="{{ route('storage.edit', $storage->id) }}" class="label label-warning">Izmeni</a>
										
										</td>
									</tr>
								@endforeach
								</tbody>
							</table>
						</div>
					</div>
				@endif
				</div>
			</div>
			@endsection


