@extends('grap.app')
@extends('layout.app')
@extends('layouts.app')




@section('content')
    <div class="container">
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif

        @endsection


        @section('header')

<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
      
      </nav>
      <a href="{{route('home')}}" class="appointment-btn scrollto">Nazad</a>


      <a href="{{route('register')}}" class="appointment-btn scrollto">Register</a>

      <a href="{{route('login')}}" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


@endsection

@section('grap')


@endsection