<?php

use Illuminate\Support\Facades\Route;
use App\Models\Products;
use App\Models\Location;
use App\Models\Storage;
use App\Models\Order;
use App\Models\Bill;
use App\Models\Admin;
use App\Models\Editor;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\StorageController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\BillController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\EditorController;
use App\Policy\ProductPolicy;
use App\Policy\AdminPolicy;
use App\Policy\EditorPolicy;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/onama',function(){
    return view('onama');
});

Route::get('/saveti',function(){
return view('saveti');
});


Route::get('/products','App\Http\Controllers\ProductController@products')->name('products.products');
Route::get('/products/add','App\Http\Controllers\ProductController@add')->name('products.add');
Route::get('/products/details/{id}','App\Http\Controllers\ProductController@details')->name('products.details');
Route::any('/products/edit/{id}','App\Http\Controllers\ProductController@edit')->name('products.edit');
Route::any('/products/delete/{id}','App\Http\Controllers\ProductController@delete')->name('products.delete');
Route::any('/products/insert','App\Http\Controllers\ProductController@insert')->name('products.insert');
Route::any('/products/update/{id}','App\Http\Controllers\ProductController@update')->name('products.update');

Route::get('/location','App\Http\Controllers\LocationController@location')->name('location.location');
Route::get('/location/details/{id}','App\Http\Controllers\LocationController@details')->name('location.details');

Route::get('/storage','App\Http\Controllers\StorageController@storage')->name('storage.storage')->middleware(['auth']);
Route::get('/storage/add','App\Http\Controllers\StorageController@add')->name('storage.add');
Route::any('/storage/insert','App\Http\Controllers\StorageController@insert')->name('storage.insert');
Route::any('/storage/details/{id}','App\Http\Controllers\StorageController@details')->name('storage.details');
Route::any('/storage/edit/{id}','App\Http\Controllers\StorageController@edit')->name('storage.edit');
Route::any('/storage/delete/{id}','App\Http\Controllers\StorageController@delete')->name('storage.delete');
Route::any('/storage/update/{id}','App\Http\Controllers\StorageController@update')->name('storage.update');

Route::any('/orders','App\Http\Controllers\OrderController@orders')->name('orders.orders')->middleware(['auth']);
Route::any('/orders/add','App\Http\Controllers\OrderController@add')->name('orders.add');
Route::any('/orders/insert','App\Http\Controllers\OrderController@insert')->name('orders.insert');
Route::any('/orders/details/{id}','App\Http\Controllers\OrderController@details')->name('orders.details');
Route::any('/bills','App\Http\Controllers\BillController@bills')->name('bills.bills')->middleware(['auth','verified']);
Route::any('/bills/add','App\Http\Controllers\BillController@add')->name('bills.add');
Route::any('/bills/insert','App\Http\Controllers\BillController@insert')->name('bills.insert');
Route::any('/comment/add','App\Http\Controllers\CommentController@add')->name('comment.add');
Route::any('/comment/insert','App\Http\Controllers\CommentController@insert')->name('comment.insert');
Route::get('/admin','App\Http\Controllers\AdminController@view')->name('admin.admin');
Route::get('/editor','App\Http\Controllers\EditorController@view')->name('editori.editor');


Route::middleware(['auth', 'verified'])->group(function () {
    Route::view('home', 'home')->name('home');
});