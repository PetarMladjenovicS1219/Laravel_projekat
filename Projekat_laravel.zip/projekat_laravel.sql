-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2021 at 12:00 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekat_laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sifra_racuna` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `iznos` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `nacin_placanja` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `sifra_racuna`, `iznos`, `created`, `nacin_placanja`, `user_id`) VALUES
(1, '10', '1110', '2021-06-16 10:24:09', 'Kes', 1),
(2, '12', '1234', '2021-06-18 10:10:35', 'qw', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Ime` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Prezime` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Adresa` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Komentar` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Datum` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `Ime`, `Prezime`, `Adresa`, `Komentar`, `Datum`) VALUES
(1, 'Petar', 'Mladjenovic', 'Zeleznicka 85', '1111', '2021-06-17 00:00:00'),
(2, 'z', 'z', 'z', '1', '2021-06-18 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Naziv_Apoteke` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Grad` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Adresa` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Postanski_broj` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `Naziv_Apoteke`, `Grad`, `Adresa`, `Postanski_broj`) VALUES
(1, 'Apoteka Mladjenovic', 'Uzce', 'Zeleznicka 85', '31000'),
(2, 'Apoteka Mladjenovic', 'Beograd', 'Vidikovacki venac 85', '11000'),
(3, 'Apoteka Mladjenovic', 'Bajina Basta', 'Mike Antica 45', '31250'),
(4, 'Apoteka Mladjenovic', 'Ljubovija', 'Patrijarha Pavla 3', '15320'),
(5, 'Apoteka Mladjenovic', 'Pozega', 'Dimitrija Tucovica 23', '31210'),
(6, 'Apoteka Mladjenovic', 'Uzice', 'Dimitrija Tucovica 65', '31000'),
(7, 'Apoteka Mladjenovic', 'Uzice', 'Omladinska 24', '31000'),
(8, 'Apoteka Mladjenovic', 'Uzice', 'Vidovdanska 77', '31000'),
(9, 'Apoteka Mladjenovic', 'Cajetina', 'Zlatiborska 5', '31310'),
(10, 'Apoteka Mladjenovic', 'Cajetina', 'Njegoseva 45', '31310');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(105, '2014_10_12_000000_create_users_table', 1),
(106, '2014_10_12_100000_create_password_resets_table', 1),
(107, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(108, '2019_08_19_000000_create_failed_jobs_table', 1),
(109, '2021_06_12_080928_create_products_table', 1),
(110, '2021_06_12_081846_create_bills_table', 1),
(111, '2021_06_12_082530_create_orders_table', 1),
(112, '2021_06_12_082649_create_storages_table', 1),
(113, '2021_06_12_082710_create_locations_table', 1),
(114, '2021_06_17_143430_create_comments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Ime_Prezime` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Naziv_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `datum_narucivanja` datetime NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `Ime_Prezime`, `Naziv_proizvoda`, `datum_narucivanja`, `user_id`) VALUES
(1, 'Pera Peric', 'Andol', '2021-06-18 10:28:45', 3),
(2, 'Mika Mikic', 'Brufen', '2021-06-18 10:29:07', 3),
(3, 'Stefan Stefanovic', 'Sumece tablete', '2021-06-18 10:29:34', 3),
(4, 'aa', 'aaa', '2021-06-18 09:57:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `naziv_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sifra_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `opis_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cena_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `datum_stavljanja_u_promet` datetime NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `naziv_proizvoda`, `sifra_proizvoda`, `opis_proizvoda`, `cena_proizvoda`, `datum_stavljanja_u_promet`, `user_id`) VALUES
(1, 'Ultra Vitamin D 2000 IU 96 tableta', '101', 'Ultra Vitamin D 2000 IU 96 tableta', '330', '2021-06-19 09:25:51', 1),
(2, 'Zincovit-C tablete', '102', 'Zincovit-C tablete', '200', '2021-06-17 17:18:48', 1),
(3, 'Solgar Hy-Bio 50 tableta', '103', 'Solgar Hy-Bio 50 tableta', '990', '2021-06-17 17:18:48', 1),
(4, 'Serazyn 10 kapsula', '104', 'Serazyn 10 kapsula', '1300', '2021-06-17 17:18:48', 1),
(5, 'GD-Poly kapsule', '105', 'GD-Poly kapsule', '440', '2021-06-17 17:18:48', 1),
(6, 'Epineuron 30 tableta\r\n\r\n', '106', 'Epineuron 30 tableta\r\n\r\n', '780', '2021-06-17 17:18:48', 1),
(7, 'Cardiovitamin 20 kapsula', '107', 'Cardiovitamin 20 kapsula', '870', '2021-06-17 17:18:48', 1),
(8, 'DeHist Snažno sredstvo protiv alergija', '108', 'DeHist Snažno sredstvo protiv alergija', '500', '2021-06-17 17:18:48', 1),
(9, 'Ecomer kapsule porodično pakovanje 240 kapsula', '109', 'Ecomer kapsule porodično pakovanje 240 kapsula', '990', '2021-06-17 17:18:48', 1),
(10, 'Pantenol krem 30g', '110', 'Pantenol krem 30g', '100', '2021-06-17 17:18:48', 1),
(11, 'Dr Plant Pantenol rastvor 5% 125 ml', '111', 'Dr Plant Pantenol rastvor 5% 125 ml', '740', '2021-06-17 17:18:48', 1),
(12, 'Pantenol mast 30g', '112', 'Pantenol mast 30g', '120', '2021-06-17 17:18:48', 1),
(13, 'Krema od lišća crvenog grožđa 250 ml\r\n\r\n', '113', 'Krema od lišća crvenog grožđa 250 ml\r\n\r\n', '1300', '2021-06-17 17:18:48', 1),
(14, 'Konjski balzam - crveni 500ml', '114', 'Konjski balzam - crveni 500ml', '1500', '2021-06-17 17:18:48', 1),
(15, 'Cedralex Krema 150ml', '115', 'Cedralex Krema 150ml', '300', '2021-06-17 17:18:48', 1),
(16, 'AH biljna krema protiv hemoroida', '116', 'AH biljna krema protiv hemoroida', '400', '2021-06-17 17:18:48', 1),
(17, 'Apivis mast - propolis mast', '117', 'Apivis mast - propolis mast', '600', '2021-06-17 17:18:48', 1),
(18, 'Brdjanski melem protiv hemoroida 50gr', '118', 'Brdjanski melem protiv hemoroida 50gr', '600', '2021-06-17 17:18:48', 1),
(19, 'Aloe vera bioaktivni gel 100ml', '119', 'Aloe vera bioaktivni gel 100ml', '320', '2021-06-17 17:18:48', 1),
(20, 'Dove Baby Rich losion za telo', '120', 'Dove Baby Rich losion za telo', '280', '2021-06-17 17:18:48', 1),
(21, 'Burra Dermalift Volume Up krema 100ml', '121', 'Burra Dermalift Volume Up krema 100ml', '1230', '2021-06-17 17:18:48', 1),
(22, 'Apivita Lavanda krema za telo 150ml', '122', 'Apivita Lavanda krema za telo 150ml', '300', '2021-06-17 17:18:48', 1),
(23, 'Apivita Jasmin mleko za telo 200ml\r\n\r\n', '123', 'Apivita Jasmin mleko za telo 200ml\r\n\r\n', '300', '2021-06-17 17:18:48', 1),
(24, 'Guam Fango topla blatna krema protiv tvrdokornog celulita', '124', 'Guam Fango topla blatna krema protiv tvrdokornog celulita', '500', '2021-06-17 17:18:48', 1),
(25, 'Bio-Oil 25ml', '125', 'Bio-Oil 25ml', '340', '2021-06-17 17:18:48', 1),
(26, 'Gel od puževe sluzi 100 ml', '126', 'Gel od puževe sluzi 100 ml', '2300', '2021-06-17 17:18:48', 1),
(27, 'Guam hladno blato od algi protiv celulita 1kg\r\n\r\n', '127', 'Guam hladno blato od algi protiv celulita 1kg\r\n\r\n', '1450', '2021-06-17 17:18:48', 1),
(28, 'Flasteri', '128', 'Flasteri za rane', '135', '2021-06-18 08:39:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `Godina` int(11) NOT NULL,
  `Prodaja` text NOT NULL,
  `Troskovi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `Godina`, `Prodaja`, `Troskovi`) VALUES
(1, 2018, '1000', '400'),
(2, 2019, '1170', '460'),
(3, 2020, '660', '1120'),
(4, 2021, '1030', '540');

-- --------------------------------------------------------

--
-- Table structure for table `storages`
--

CREATE TABLE `storages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Naziv_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Kolicina_proizvoda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rok_trajanja` datetime NOT NULL,
  `Datum_nabavke` datetime NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `storages`
--

INSERT INTO `storages` (`id`, `Naziv_proizvoda`, `Kolicina_proizvoda`, `Rok_trajanja`, `Datum_nabavke`, `user_id`) VALUES
(1, 'Ultra Vitamin D 2000 IU 96 tableta', '55', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(2, 'Zincovit-C tablete', '45', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(3, 'Solgar Hy-Bio 50 tableta', '35', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(4, 'Serazyn 10 kapsula', '22', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(5, 'GD-Poly kapsule', '65', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(6, 'Epineuron 30 tableta', '97', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(7, 'Cardiovitamin 20 kapsula', '33', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(8, 'DeHist Snažno sredstvo protiv alergija', '61', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(9, 'Ecomer kapsule porodično pakovanje 240 kapsula', '31', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(10, 'Pantenol krem 30g', '20', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(11, 'Dr Plant Pantenol rastvor 5% 125 ml', '76', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(12, 'Pantenol mast 30g\r\n\r\n', '145', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(13, 'Krema od lišća crvenog grožđa 250 ml', '10', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(14, 'Konjski balzam - crveni 500ml', '52', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(15, 'Cedralex Krema 150ml\r\n\r\n', '30', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(16, 'AH biljna krema protiv hemoroida\r\n\r\n', '6', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(17, 'Apivis mast - propolis mast\r\n\r\n', '15', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(18, 'Brdjanski melem protiv hemoroida 50gr\r\n\r\n', '44', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(19, 'Aloe vera bioaktivni gel 100ml\r\n\r\n', '32', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(20, 'Dove Baby Rich losion za telo\r\n\r\n', '56', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(21, 'Burra Dermalift Volume Up krema 100ml\r\n\r\n', '66', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(22, 'Apivita Lavanda krema za telo 150ml\r\n\r\n', '47', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(23, 'Apivita Jasmin mleko za telo 200ml\r\n\r\n', '12', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(24, 'Guam Fango topla blatna krema protiv tvrdokornog celulita', '19', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(25, 'Bio-Oil 25ml\r\n\r\n', '25', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(26, 'Gel od puževe sluzi 100 ml\r\n\r\n', '17', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1),
(27, 'Guam hladno blato od algi protiv celulita 1kg\r\n\r\n', '36', '2021-06-17 17:29:36', '2021-06-17 17:29:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'registered'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`, `user_type`) VALUES
(1, 'admin', 'admin@admin.com', NULL, '$2y$10$xTNBmNhOrOPtcE8qUHPFye2PCu9zxh5BgtZCxiTG.yiVc90EtrOCe', NULL, NULL, NULL, '2021-06-17 13:15:14', '2021-06-17 13:15:14', 'admin'),
(2, 'editor', 'editor@editor.com', NULL, '$2y$10$HR4Zy1XVFG3EgZWH7lXfFuGWHjowtgP6Bl20IFLYxHQmfzVcD6FNm', NULL, NULL, NULL, '2021-06-17 13:16:23', '2021-06-17 13:16:23', 'editor'),
(3, 'user', 'user@user.com', NULL, '$2y$10$RTMv2XPnLkeTFSbtK/m95.Nz1dHDdMGGGM78GAvOg58mze1K7XE56', NULL, NULL, NULL, '2021-06-17 13:16:49', '2021-06-17 13:16:49', 'registered');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bills_user_id_index` (`user_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_index` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_user_id_index` (`user_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `storages`
--
ALTER TABLE `storages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `storages_user_id_index` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `storages`
--
ALTER TABLE `storages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bills`
--
ALTER TABLE `bills`
  ADD CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `storages`
--
ALTER TABLE `storages`
  ADD CONSTRAINT `storages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
