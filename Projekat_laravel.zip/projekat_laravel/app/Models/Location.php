<?php

namespace App\Models;
use App\Http\Controllers\LocationController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    protected $fillable = ['Naziv_Apoteke', 'Grad','Adresa','Postanski_broj'];
}
