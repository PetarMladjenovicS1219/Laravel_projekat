@extends('layout.app')

@section('bar')

<div id="topbar">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:contact@example.com">pmladjenovic1219s@raf.rs</a>
        <i class="icofont-phone"></i> +381 60 72 60 180
        <i class="icofont-google-map"></i> Zeleznicka 85, UE
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="skype"><i class="icofont-skype"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

@endsection


@section('header')

<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="/projekat_laravel/public">Pocetna</a></li>
          <li><a href="{{ route('products.products') }}">Proizvodi</a></li>
		  <li><a href="{{ route('orders.orders') }}">Narudzbenice</a></li>
          <li><a href="{{ route('location.location') }}">Lokacije</a></li>
          <li><a href="{{route('storage.storage')}}">Magacin</a></li>
          <li><a href="{{route('bills.bills')}}">Racuni</a></li>
          <li class="drop-down"><a href="">Apoteka</a>
            <ul>
              <li><a href="/projekat_laravel/public/onama">O nama</a></li>
              
              <li class="active"><a href="/projekat_laravel/public/saveti">Saveti</a></li>
              
            </ul>
          </li>
         
        </ul>
      </nav>
      <a href="{{route('register')}}" class="appointment-btn scrollto">Register</a>

      <a href="{{route('login')}}" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


@endsection

@section('content')
<center><h3>KUĆNA APOTEKA </h3></center>
<p>Svaka kuća bi trebalo da sadrži određene medikamente kao prvu pomoć kod različitih zdravstvenih problema, povreda, alergija, ujeda insekata…</p>
<p>Naši farmaceuti daju odgovore na najčešća pitanja pacijenata:</p><br><br>

<p><strong>Koliko često kontrolišemo kućnu apoteku, kako se ona ispravno drži i da li samo na jednom mestu?</strong></p>
<p>Preporuka je da se svi lekovi, uključujući magistralne i galenske, kao i pomoćna lekovita sredstva pregledaju jednom u 6 meseci.
Sigurno smo da će kolege iz njihovih najbližih apoteka uvek biti spremni da pomognu u pregledanju sadržaja kućne apoteke.
Praksa ipak pokazuje da se lekovi iz kućne apoteke ne kontrolišu nijednom godišnje, naročita starija populacija.

Kućnu apoteku bi trebalo držati na jednom mestu, odvojeno, po mogućnosti u ormarićima, fiokama, kutijama.
Zaklonjeno od direktne svetlosti i vlage (zato kupatilo nije dobar izbor) i svakako van domašaja dece.

Lekove ne treba vaditi iz originalnog pakovanja jer su na njima najvidljiviji podaci o nazivu leka i roku trajanja.

</p><br><br>
<p><strong>Šta se drži u frižderu i da li je to opasno?</strong></p><br><br>
<p>Prilikom izdavanja lekova u apoteci pacijenti će biti upozoreni da lek moraju čuvati u frižderu na temperaturi od 2°C do 8°C.
Obavezno ih držati odvojeno od namirnica.
To mogu biti insulini, rastvoreni antibiotski sirupi, neke kapi za oči, kao i određeni probiotici…</p><br><br>

<p><strong>Šta radimo sa lekovima kojima je istekao rok trajanja, kako se pravilno odlažu?</strong></p><br><br>
<p>Sve apoteke su u obavezi da preuzmu lekove sa isteklim rokom trajanja od građanstva. U pripremi je pravilnik koji će dalje
definisati na čiji teret pada obaveza krajnjeg zbrinjavanja farmaceutskog otpada.</p><br><br>

<p><strong>Šta obavezno treba da imamo u kućnoj apoteci, a čemu tu nije mesto?</strong></p><br><br>
<p>Od lekova u kućnoj apoteci su najvažniji analgetici (za umirenje bolova), antipiretici (za snižavanje temperature),
probiotici (za saniranje blažih oblika dijareje), lekovi za ublažavanje želudačnih tegoba, lekovi protiv alergija, laksativi,
preparati za ublažavanje upale grla i lakših oblika kašlja i nazeba, preparati za brzu epitelizaciju i saniranje opekotina.
Od galenskih proizvoda obavezno treba imati antiseptike kao što su alkohol i hidrogen, a od medicinskih sredstava toplomer,
flastere, gaze, zavoje.
U kućnoj apoteci svakako nema mesta za antibiotike jer ih ne treba koristiti prilikom samomedikacije. Sa sedativima takođe
treba veliki oprez u korišćenju i uputstvu lekara o jačini sedativa i dužini trajanja terapije.</p><br><br>

<p><strong>Kako je formiramo, da li bi trebalo da je obnavljamo uvek u isto doba godine kako bismo bili sigurni da je sve
upotrebljivo (kada zatreba u pola noći)?</strong></p><br><br>

<p>Već je navedeno koji se proizvodi preporučljivi kao sadržaj kućne apoteke koji se obično dopunjuju proizvodima nakon nekog putovanja.

Ne treba čuvati otvorene lekove nakon saniranih akutnih tegoba npr. antibiotike.

Lekovi koji se izrađuju u apoteci po receptu lekara obično imaju kraći rok trajanja i o njima bi trebalo naročito voditi računa.</p><br><br>
<p><strong>Da li bi pri kupovini, trebalo da gledamo i pitamo koji je rok trajanja leka?</strong></p><br><br>
<p>U apotekama se strogo vodi računa o rokovima trajanja lekova i sigurno ćete biti upozoreni od strane farmaceuta, naročito ako je
rok trajanja leka kraći od 6 meseci. Trebalo bi uvek obratiti pažnju, naročito ako preparat neće biti odmah korišćen nakon kupovine.</p><br><br>
<p><strong>Probiotici i analgetici su dve vrste lekova koje najčešće uzimamo na svoju ruku. Gde grešimo?</strong></p><br><br>
<p>Analgetici su lekovi koje koristimo kod akutnog stanja bola. Dužom i prekomernom upotrebom, izlažemo sebe pojavi mogućih
neželjenih efekata kao što je slučaj kod nesteroidnih antireumatika koji imaju štetan uticaj na sluzokožu želuca. Slično je i sa
probioticima koji se upotrebljavaju u određenim situacijama, određeni broj dana.

Ukoliko zdravstveni problemi traju duže od nekoliko dana neophodno je obratiti se lekaru i prekinuti sa samomedikacijom.
Bitno je potražiti uzrok problema, a ne samostalno sanirati posledice.</p>

@endsection