@extends('lay.app')
@extends('layouts.app')




			@section('cont')
			<div class="row">
				<div class="col-lg-12 margin-tb">
					<div class="pull-left">
						<h2>Apoteka Mladjenovic</h2>
					</div>
					<div class="pull-right">
						<a href="{{ route('storage.storage') }}" class="label label-primary pull-right">Nazad</a>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Naziv Proizvoda:</strong>
						{{ $storages->Naziv_proizvoda }}
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Kolicina proizvoda:</strong>
						{{ $storages->Kolicina_proizvoda }}
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Rok trajanja:</strong>
						{{$storages->Rok_trajanja }}
					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Datum nabavke:</strong>
						{{$storages->Datum_nabavke }}
					</div>
				</div>
			</div>
			@endsection