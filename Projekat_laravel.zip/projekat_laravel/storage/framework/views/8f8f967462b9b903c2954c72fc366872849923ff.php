<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Medilab Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab - v2.1.1
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php echo $__env->yieldContent('bar'); ?>

    <?php echo $__env->yieldContent('header'); ?>

    <?php echo $__env->yieldContent('hero'); ?>

    <?php echo $__env->yieldContent('section'); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->yieldContent('about'); ?>

    <?php echo $__env->yieldContent('counts'); ?>

    <?php echo $__env->yieldContent('services'); ?>

    <?php echo $__env->yieldContent('appointment'); ?>

    <?php echo $__env->yieldContent('departments'); ?>

    <?php echo $__env->yieldContent('docotors'); ?>

    <?php echo $__env->yieldContent('frequently'); ?>

    <?php echo $__env->yieldContent('testomionials'); ?>

    <?php echo $__env->yieldContent('gallery'); ?>

    <?php echo $__env->yieldContent('contact'); ?>

    <?php echo $__env->yieldContent('footer'); ?>

    
</body><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/layout/app.blade.php ENDPATH**/ ?>