





			<?php $__env->startSection('cont'); ?>
			<div class="row">
				<div class="col-lg-12 margin-tb">
					<div class="pull-left">
						<h2>Apoteka Mladjenovic</h2>
					</div>
					<div class="pull-right">
						<a href="<?php echo e(route('location.location')); ?>" class="label label-primary pull-right">Nazad</a>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Naziv Apoteke:</strong>
						<?php echo e($locations->Naziv_Apoteke); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Grad:</strong>
						<?php echo e($locations->Grad); ?>

					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Adresa:</strong>
						<?php echo e($locations->Adresa); ?>

					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Postanski broj:</strong>
						<?php echo e($locations->Postanski_broj); ?>

					</div>
				</div>
			</div>
			<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('lay.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/location/details.blade.php ENDPATH**/ ?>