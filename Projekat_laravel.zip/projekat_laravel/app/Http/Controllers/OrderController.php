<?php

namespace App\Http\Controllers;

use App\Models\Order;

use App\Models\Product;

use Illuminate\Http\Request;

use Session;
use Illuminate\Pagination\Paginator;
class OrderController extends Controller
{

public function orders(Request $request){

    if ($request->user()->cannot('viewAny', Order::class)) {
        abort(403);
    }

    $orders = Order::paginate(5);
    return view('orders.orders',['orders'=>$orders]);
}

public function details($id){
    $orders = Order::find($id);
    return view('orders.details',['orders'=>$orders]);
}



public function add(){
    return view('orders.add');
}

public function insert(Request $request){

    if ($request->user()->cannot('create', Order::class)) {
        abort(403);
    }


    $this->validate($request, [
        'Naziv_proizvoda' => 'required',
        'Ime_Prezime' => 'required',
      
        
    ]);
    
    //get post data
    $postData = $request->all();
    
    //insert post data
    Order::create($postData);
    
    //store status message
    Session::flash('success_msg', 'Narudzbenica je dodata u bazu uspesno!');

    return redirect()->route('orders.add');

}
public function product(){
    $products = Product::orderBy('id','desc')->get();
    return view('products.products',['products'=>$products]);
     
}




}
