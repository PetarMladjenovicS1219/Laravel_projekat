@extends('layout.app')

@section('bar')

<div id="topbar">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:contact@example.com">pmladjenovic1219s@raf.rs</a>
        <i class="icofont-phone"></i> +381 60 72 60 180
        <i class="icofont-google-map"></i> Zeleznicka 85, UE
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="skype"><i class="icofont-skype"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

@endsection


@section('header')
<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="/projekat_laravel/public">Pocetna</a></li>
          <li><a href="{{ route('products.products') }}">Proizvodi</a></li>
		  <li><a href="{{ route('orders.orders') }}">Narudzbenice</a></li>
          <li><a href="{{ route('location.location') }}">Lokacije</a></li>
          <li><a href="{{route('storage.storage')}}">Magacin</a></li>
          <li><a href="{{route('bills.bills')}}">Racuni</a></li>
          <li class="drop-down"><a href="">Apoteka</a>
            <ul>
            <li class="active"><a href="/projekat_laravel/public/onama">O nama</a></li>
              
              <li><a href="/projekat_laravel/public/saveti">Saveti</a></li>
              
            </ul>
          </li>
         
        </ul>
      </nav>
      <a href="{{route('register')}}" class="appointment-btn scrollto">Register</a>

      <a href="{{route('login')}}" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


@endsection

@section('content')
<center><h1>Apoteka Mladjenovic</h1></center><br>
<p>
Prisutni smo na 400 lokacija širom naše zemlje i biće nas još. Apotekarska ustanova Apoteka Mladjenovic je najveći lanac apoteka u Srbiji i deo je velike međunarodne kompanije PHOENIX iz Nemačke. Ono po čemu se Apoteka Mladjenovic izdvaja na tržištu jeste konstantan rad sa zaposlenim farmaceutima na usavršavanju i upoznavanju najnovijih dostignuća medicine i farmakologije, sa ciljem da se pacijentima ponudi najbolji mogući savet. Apoteka Mladjenovic u svom poslovanju primenjuje najsavremenije evropske standarde u nabavci, distribuciji, skladištenju i izlaganju lekova i lekovitih sredstava, sve sa ciljem maksimalne bezbednosti za pacijente.</p><br><br>


<p>
U svojoj ponudi, Apoteka Mladjenovic poseduje i liniju proizvoda pomoćnih lekovitih sredstava LIVSANE vrhunskog kvaliteta, uglavnom proizvedenih u Nemačkoj. Svakog meseca, u saradnji sa renomiranim farmaceutskim i kozmetičkim kompanijama, organizujemo brojne akcije pomoću kojih predstavljamo naš asortiman.
</p><br><br>


<strong><p>JEDINSTVENOST Apoteke Mladjenovic BRENDA</p></strong><br>

<p>Apoteke Mladjenovic apoteke odlikuje nov i moderan pristup u sprovođenju farmaceutske usluge u oblasti medicinske zaštite i prevencije. Prillagođena zahtevima savremenog potrošača, Apoteke Mladjenovic apoteka pruža mogućnost samostalnog istraživanja proizvoda uz konsultacije sa stručnim farmaceutima i u skladu sa principima dobre farmaceutske prakse.

Apoteke Mladjenovic brend svoju prepoznatljivost zasniva i na jedinstvenom stilu izlaganja proizvoda i modernom i privlačnom dizajnu enterijera apoteke, kombinaciji svedene forme, komfora i topline koji čine jedinstven osećaj udobnosti i dobrodošlice u svakom objektu Apoteke Mladjenovic. Izlaganje proizvoda u Apoteke Mladjenovic apotekama zasniva se na konceptu otvorene apoteke, slobodnog prostora i direktnog pristupa atraktivnom asortimanu.

Stručno i ljubazno osoblje Apoteke Mladjenovic apoteka pružiće pravi savet i olakšati izbor proizvoda, jer svakom kupcu pristupa sa aspekta specifičnosti njegovih potreba.</p><br><br>

<strong><p>FILOZOFIJA 5 ČULA - 5 VREDNOSTI Apoteke Mladjenovic
KOMPETENTNOST</p></strong>
<p><br><br>
Naše stručno osoblje daje našim klijentima savete o proizvodima i njihovom uticaju na sve aspekte zdravlja. Trudimo se da svojim kupcima približimo Apoteke Mladjenovic apoteku i njene zaposlene kao deo porodice koja brine o njima. Doslednost i pouzdanost su naš imperativ, a proizvodi koje nudimo su strogo kontrolisani i vrhunskog kvaliteta.

<strong><p>LJUBAZNOST</p></strong><br>
Ljubaznost i prijateljsko ophođenje su osobine koje krase naše zaposlene, a dvosmerna komunikacija je osnov farmaceutske usluge. Uz to, trudimo se da osećaj da se naši klijenti nalaze u dobrim rukama i u prijateljskom okruženju nikada ne izbledi.

<strong><p>SVEŽINA</p></strong><br><br>
Trudimo se da, od prvog koraka u apoteci, naš klijent oseti živu energiju i vitalnost. Proaktivan i pozitivan pristup su neizostavan deo naših saveta. Kreiramo dobar osećaj i enterijerom naše apoteke pružamo mogućnost jedinstvenog iskustva u korišćenju i istraživanju naših proizvoda. Verujemo da jedino tako možemo doprineti dobrom raspoloženju naših klijenata i njihovoj veri u neophodnost preventive i negovanja zdravih životnih navika.

<strong><p>INOVATIVNOST</p></strong><br>
Verujemo u inovativan pristup potrebama klijenata i primenu novih medicinskih saveta i preventive. Svesni da društvo sve više pažnje pridaje negovanju zdravih životnih navika dajemo svoj doprinos kroz edukaciju klijenata i odgovore i na njihova nepostavljena pitanja. Budućnost pripada inovativnim kompanijama, a Apoteke Mladjenovic apoteke su u tome lideri. To pokazujemo u svakom segmentu naše usluge i milimetru prostora.

<br><strong><p>POSVEĆENOST</p></strong><br><br>
Već pri prvom kontaktu se trudimo da prepoznamo potrebe naših klijenata i odgovorimo na njih. Briga o našim klijentima nam je uvek u fokusu, a kreativnim pristupom se trudimo da svakom od njih pružimo osećaj jedinstvenosti i posebnosti. U osnovi naše posvećenosti leži timski duh naših zaposlenih i kreiranje dobrobiti svih naših klijenata.

<p><strong>Apoteke Mladjenovic ASORTIMAN</strong></p><br>
Asortiman naših proizvoda odlikuje sveobuhvatnost i prilagodljivost zahtevima tržišta, potrebama klijenata i sezonalnosti. Apoteke Mladjenovic asortiman obuhvata veliki broj različitih kategorija organizovanih prema principima preglednosti i dostupnosti. Otvoreni prostor naših apoteka svakom klijentu omogućava više informacija i saznanja u domenu kozmetike i drugih preparata za negu, dijetetskih suplemenata i drugog. Izbor je na našim klijentima, a naše je da omogućimo da u pravom okruženju izaberu pravi proizvod, u pravo vreme.
</p>
@endsection

