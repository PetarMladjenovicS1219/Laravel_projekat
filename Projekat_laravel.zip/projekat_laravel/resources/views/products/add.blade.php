@extends('lay.app')
@extends('layouts.app')

@section('cont')
<div class="row">
    <div class="col-lg-12">
        @if($errors->any())
            <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach()
            </div>
        @endif
        <div class="panel panel-default">
            <div class="panel-heading">
                Add a New Post <a href="{{ route('products.products') }}" class="label label-primary pull-right">Nazad</a>
            </div>
            <div class="panel-body">
                <form action="{{ route('products.insert') }}" method="POST" class="form-horizontal">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Naziv proizvoda</label>
                        <div class="col-sm-10">
                            <input type="text" name="naziv_proizvoda" id="naziv_proizvoda" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Sifra proizvoda</label>
                        <div class="col-sm-10">
                        <input type="text" name="sifra_proizvoda" id="sifra_proizvoda" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Opis proizvoda</label>
                        <div class="col-sm-10">
                            <textarea name="opis_proizvoda" id="opis_proizvoda" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Cena proizvoda</label>
                        <div class="col-sm-10">
                        <input type="text" name="cena_proizvoda" id="cena_proizvoda" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Datum stavljanja u promet</label>
                        <div class="col-sm-10">
                        <input type="date" name="datum_stavljanja_u_promet" id="datum_stavljanja_u_promet" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-default" value="Add Post" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection