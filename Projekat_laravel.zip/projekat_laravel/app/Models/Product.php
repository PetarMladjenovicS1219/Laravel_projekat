<?php

namespace App\Models;
use App\Policies\ProductPolicy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['naziv_proizvoda', 'sifra_proizvoda','opis_proizvoda','cena_proizvoda'];

    const CREATED_AT = 'datum_stavljanja_u_promet';
    const UPDATED_AT = 'datum_stavljanja_u_promet';
    


    

}
