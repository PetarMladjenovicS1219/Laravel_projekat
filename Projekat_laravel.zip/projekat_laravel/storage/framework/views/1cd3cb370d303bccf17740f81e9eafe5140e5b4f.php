




<?php $__env->startSection('header'); ?>
<header id="header">
    <div class="container d-flex align-items-center">

    <h1 class="logo mr-auto"><a href="/projekat_laravel/public">Apoteka Mladjenovic</a></h1>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="/projekat_laravel/public">Pocetna</a></li>
          <li><a href="<?php echo e(route('products.products')); ?>">Proizvodi</a></li>
		  <li><a href="<?php echo e(route('orders.orders')); ?>">Narudzbenice</a></li>
          <li><a href="<?php echo e(route('location.location')); ?>">Lokacije</a></li>
          <li><a href="<?php echo e(route('storage.storage')); ?>">Magacin</a></li>
		  <li class="active"><a href="<?php echo e(route('bills.bills')); ?>">Racuni</a></li>
          <li class="drop-down"><a href="">Apoteka</a>
            <ul>
              <li><a href="/projekat_laravel/public/onama">O nama</a></li>
              
              <li><a href="/projekat_laravel/public/saveti">Saveti</a></li>
              
            </ul>
          </li>
         
        </ul>
      </nav>
      <a href="<?php echo e(route('register')); ?>" class="appointment-btn scrollto">Register</a>

      <a href="<?php echo e(route('login')); ?>" class="appointment-btn scrollto">Login</a>

    </div>
  </header>


<?php $__env->stopSection(); ?>



			<?php $__env->startSection('cont'); ?>
		
			<div class="row">
				<div class="col-lg-12">
					<?php if(Session::has('success_msg')): ?>
					<div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
					<?php endif; ?>
				<!-- Posts list -->
				<?php if(!empty($bills)): ?>
					<div class="row">
						<div class="col-lg-12 margin-tb">
							<div class="pull-left">
							<?php echo $bills->links(); ?>

								<h2>Katalog proizvoda</h2>
							</div>
							<div class="pull-right">
							
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12">
							<table class="table table-striped task-table">
								<!-- Table Headings -->
								<thead>
                                <th width="25%">id</th>
									<th width="25%">Ime Prezime</th>
									<th width="20%">Ime proizvoda</th>
									<th width="35%">Iznos</th>
                                    <th width="15%">Datum</th>
								

								</thead>
				
								<!-- Table Body -->
								<tbody>
								<?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
                                    <td class="table-text">
											<div><?php echo e($bill->id); ?></div>
										</td>
										<td class="table-text">
											<div><?php echo e($bill->sifra_racuna); ?></div>
										</td>
										<td class="table-text">
											<div><?php echo e($bill->iznos); ?></div>
										</td>
											<td class="table-text">
											<div><?php echo e($bill->created); ?></div>
										</td>
                                        <td class="table-text">
											<div><?php echo e($bill->nacin_placanja); ?></div>
										</td>
                  
										<td>
											
								
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
				<?php endif; ?>
				</div>
				
			</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('lay.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekat_laravel\resources\views/bills/bills.blade.php ENDPATH**/ ?>