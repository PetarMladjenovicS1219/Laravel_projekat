<?php

namespace App\Http\Controllers;
use App\Models\Order;
use App\Models\Bill;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;

use Session;
class BillController extends Controller
{
   
    public function bills(Request $request){
          
        if ($request->user()->cannot('viewAny', Bill::class)) {
            abort(403);
        }

        $bills = Bill::paginate(5);
    
        return view('bills.bills',['bills'=>$bills]);
    }


    public function add(){
        return view('bills.add');
    }
    
    public function insert(Request $request){

        if ($request->user()->cannot('create', Bill::class)) {
            abort(403);
        }   

        $this->validate($request, [
            
            'iznos' => 'required'
        ]);
        
        //get post data
        $postData = $request->all();
        
        //insert post data
        Bill::create($postData);
        
        //store status message
        Session::flash('success_msg', 'Racun je dodat u bazu uspesno!');
    
        return redirect()->route('orders.orders');
    
    }
    
    


}
