@extends('lay.app')
@extends('layouts.app')

			@section('cont')
			<div class="row">
				<div class="col-lg-12 margin-tb">
					<div class="pull-left">
						<h2>Proizvod detaljnije</h2>
					</div>
					<div class="pull-right">
						<a href="{{ route('products.products') }}" class="label label-primary pull-right"> Nazad</a>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Id:</strong>
						{{ $products->id }}
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Naziv proizvoda:</strong>
						{{ $products->naziv_proizvoda }}
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Sifra porizvoda:</strong>
						{{ $products->sifra_proizvoda }}
					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Opis Proizvoda:</strong>
						{{ $products->opis_proizvoda }}
					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Cena proizvoda:</strong>
						{{ $products->cena_proizvoda }}
					</div>
				</div>
                <div class="col-xs-12 col-sm-12 col-md-12">
					<div class="form-group">
						<strong>Datum stavljanja u promet:</strong>
						{{ $products->datum_stavljanja_u_promet }}
					</div>
				</div>
			</div>
			@endsection

